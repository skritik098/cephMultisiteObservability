"""Allow running as: python -m rgw_monitor"""
import sys
from .cli import main
sys.exit(main())
