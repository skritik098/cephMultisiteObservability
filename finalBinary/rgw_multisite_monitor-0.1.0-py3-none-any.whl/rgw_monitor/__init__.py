"""Ceph RGW Multisite Replication Monitor."""

__version__ = "0.1.0"
